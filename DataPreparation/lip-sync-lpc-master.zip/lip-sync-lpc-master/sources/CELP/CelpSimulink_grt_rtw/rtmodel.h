/*
 *  rtmodel.h:
 *
 * Real-Time Workshop code generation for Simulink model "CelpSimulink.mdl".
 *
 * Model Version              : 1.10
 * Real-Time Workshop version : 7.1  (R2008a)  23-Jan-2008
 * C source code generated on : Mon Oct 31 17:46:25 2011
 */
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_

/*
 *  Includes the appropriate headers when we are using rtModel
 */
#include "CelpSimulink.h"
#endif                                 /* RTW_HEADER_rtmodel_h_ */
