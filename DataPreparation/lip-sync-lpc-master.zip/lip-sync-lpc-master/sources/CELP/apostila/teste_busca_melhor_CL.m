N = 5;

[g, i] =busca_melhor_CL(speech_frame,codeblock,N);

figure
plot(speech_frame);
hold on

plot((codeblock(:,i))*(g),'r');

legend('Original',sprintf('N = %d',N));