tar -C .. -zcf p2fa_1.002.tgz \
	p2fa/align.py p2fa/changes.txt p2fa/examples \
	p2fa/__init__.py p2fa/model p2fa/readme.txt p2fa/test
